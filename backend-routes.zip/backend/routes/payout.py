from fastapi import APIRouter, Depends, HTTPException, Header
from sqlalchemy.orm import Session
from datetime import datetime, timezone
import uuid
from backend.database import get_db
from backend.models import Wallet, Withdrawal, WithdrawRequest, WalletTransaction, WebhookDeliveryLog, Webhook
from backend.services.webhook_service import send_webhook_event
from backend.middleware.authorization import require_owner
from backend.models import WorkspaceUser
from backend.auth import get_current_user
from backend.services.workspace_service import (
    get_workspace_owner_id
)
from sqlalchemy import func
from backend.models import Payment, Link, UserDB, Profile, generate_prefixed_id
from fastapi import Request
import json
import time
import hmac
import hashlib
import requests
import os
import stripe

stripe.api_key = os.getenv("STRIPE_SECRET_KEY")


STRIPE_WEBHOOK_SECRET = os.getenv("STRIPE_WEBHOOK_SECRET")
print(stripe.api_key)


router = APIRouter()

@router.get("/wallet/me")
def get_wallet(
    db: Session = Depends(get_db), 
    user=Depends(get_current_user),
    workspace_id: str = Header(
        None,
        alias="X-Workspace-Id"
    )
):
    owner_id = get_workspace_owner_id(
        user,
        workspace_id,
        db
    )

    wallet = db.query(Wallet).filter(Wallet.user_id == owner_id).first()

    if not wallet:
        raise HTTPException(404, "Wallet not found")
    
    now = datetime.now(timezone.utc)

    txs = db.query(WalletTransaction).filter(
        WalletTransaction.user_id == owner_id
    ).all()

    deposits = [tx for tx in txs if tx.type == "deposit"]
    withdrawals = [tx for tx in txs if tx.type == "withdraw"]

    unlocked_deposits = sum(
        tx.amount for tx in deposits
        if not tx.available_at or tx.available_at <= now
    )

    locked_amount = sum(
        tx.amount for tx in txs
        if tx.type == "deposit" and tx.available_at and tx.available_at > now
    )

    withdrawn_total = sum(
        tx.amount for tx in withdrawals
        if tx.status in ("pending", "processing", "success")
    )

    available_amount = unlocked_deposits - withdrawn_total

    future_dates = [tx.available_at for tx in txs if tx.available_at and tx.available_at > now]
    next_available_at = min(future_dates) if future_dates else None

    return {
        "available": available_amount,
        "pending_withdrawal": wallet.pending,
        "locked_amount": locked_amount,
        "next_available_at": next_available_at
    }


@router.get("/wallet/history")
def get_wallet_history(
    db: Session = Depends(get_db),
    user = Depends(get_current_user),
    workspace_id: str = Header(
        None,
        alias="X-Workspace-Id"
    )
):
    owner_id = get_workspace_owner_id(user, workspace_id, db)
    txs = db.query(WalletTransaction)\
        .filter(WalletTransaction.user_id == owner_id)\
        .order_by(WalletTransaction.created_at.desc())\
        .all()
    transactions_data = []
    for tx in txs:
        wd = db.query(Withdrawal).filter(Withdrawal.reference == tx.reference).first()
        display_status = wd.status if wd else tx.status
        transactions_data.append({
            "id": wd.id if wd else tx.id,
            "withdrawal_id": wd.id if wd else None,
            "amount": tx.amount,
            "direction": tx.direction,
            "type": tx.type,
            "status": display_status,
            "description": tx.description,
            "reference": tx.reference,
            "created_at": tx.created_at.isoformat(),
        })
    return {"transactions": transactions_data}

@router.post("/withdraw")
def withdraw(
    req: WithdrawRequest, 
    db: Session = Depends(get_db), 
    membership: WorkspaceUser = Depends(require_owner)
):
    owner_id = membership.workspace_id

    print("ROUTE /withdraw appelée")

    from backend.services.wallet_service import create_wallet_transaction

    wallet = db.query(Wallet)\
        .filter(Wallet.user_id == owner_id)\
        .with_for_update()\
        .first()

    if not wallet:
        raise HTTPException(404, "Wallet not found")

    # 🔥 sécurité
    if req.amount <= 0:
        raise HTTPException(400, "Invalid amount")
    
    now = datetime.now(timezone.utc)

    next_available = db.query(WalletTransaction.available_at)\
        .filter(
            WalletTransaction.user_id == owner_id,
            WalletTransaction.type == "deposit",
            WalletTransaction.status == "success",
            WalletTransaction.available_at > now
        )\
        .order_by(WalletTransaction.available_at.asc())\
        .first()

    print("DEBUG TX:")
    for tx in db.query(WalletTransaction).filter(WalletTransaction.user_id == owner_id).all():
        print(tx.type, tx.status, tx.amount, tx.available_at)

    available_amount = db.query(func.sum(WalletTransaction.amount)).filter(
        WalletTransaction.user_id == owner_id,
        WalletTransaction.type == "deposit",
        WalletTransaction.status == "success",
        WalletTransaction.available_at <= now
    ).scalar() or 0

    print("AVAILABLE_STRIPE:", available_amount)
    print("AVAILABLE_WALLET:", wallet.available)

    # ✅ check réel Stripe
    if available_amount < req.amount:
        raise HTTPException(
            400,
            detail={
                "message": "Funds not yet available",
                "next_available_at": next_available[0].isoformat() if next_available else None
            }
        )

    print(f"[WITHDRAW BEFORE] owner={owner_id} available={wallet.available} pending={wallet.pending}")

    # 🔒 lock les fonds
    wallet.available -= req.amount
    wallet.pending += req.amount

    print(f"[WITHDRAW AFTER] owner={owner_id} available={wallet.available} pending={wallet.pending}")

    ref = generate_prefixed_id("wd")

    print(f"[NEW WITHDRAW] owner={owner_id} amount={req.amount} ref={ref}")

    withdrawal = Withdrawal(
        user_id=owner_id,
        wallet_id=wallet.id,
        amount=req.amount,
        status="pending",
        reference=ref
    )
    
    create_wallet_transaction(
        db=db,
        user_id=owner_id,
        wallet_id=wallet.id,
        amount=req.amount,
        type="withdraw",
        direction="out",
        status="pending",
        reference=ref, 
        description="Retrait en attente"
    )


    db.add(withdrawal)
    db.commit()
    db.refresh(withdrawal)

    return {
        "status": "pending",
        "id": withdrawal.id,
        "next_available_at": next_available[0] if next_available else None
    }
    
@router.post("/withdraw/{id}/process")
def process_withdraw(
    id: str, 
    db: Session = Depends(get_db)
):
    wd = db.query(Withdrawal)\
        .filter(Withdrawal.id == id)\
        .with_for_update()\
        .first()
    if not wd:
        raise HTTPException(404, "Withdrawal not found")
    if wd.status in ["processing", "success"]:
        return {"error": "already processed"}
    wallet = db.query(Wallet)\
        .filter(Wallet.id == wd.wallet_id)\
        .with_for_update()\
        .first()
    if not wallet:
        raise HTTPException(404, "Wallet not found")
    user = db.query(UserDB).filter(UserDB.id == wd.user_id).first()
    profile = db.query(Profile).filter(Profile.user_id == user.id).first()
    if not profile or not profile.stripe_account_id:
        raise HTTPException(400, "Stripe account not connected")
    account = stripe.Account.retrieve(profile.stripe_account_id)
    if not account["payouts_enabled"]:
        raise HTTPException(400, "Payouts not enabled")
    USD_RATE = 577.325
    usd_amount = wd.amount / USD_RATE
    amount_cents = int(usd_amount * 100)
    if amount_cents <= 0:
        raise HTTPException(400, "Amount too small")
    balance = stripe.Balance.retrieve(
        stripe_account=profile.stripe_account_id
    )
    instant_available = sum(b["amount"] for b in balance["instant_available"])
    if instant_available < amount_cents:
        raise HTTPException(400, "Insufficient Stripe balance")
    wd.status = "processing"
    db.flush()
    try:
        payout = stripe.Payout.create(amount=amount_cents, currency="usd", stripe_account=profile.stripe_account_id, method="instant")
        wd.status = payout["status"]
        wd.stripe_payout_id = payout["id"]
        wallet.pending -= wd.amount
        tx = db.query(WalletTransaction).filter(WalletTransaction.reference == wd.reference).first()
        if tx:
            tx.status = payout["status"]
            tx.description = f"Retrait {payout['status']}"
    except Exception as e:
        wd.status = "failed"
        wallet.pending -= wd.amount
        wallet.available += wd.amount 
        tx = db.query(WalletTransaction).filter(WalletTransaction.reference == wd.reference).first()
        if tx:
            tx.status = "failed"
            tx.description = "Retrait échoué"
    wd.processed_at = datetime.now(timezone.utc)
    db.commit()
    send_webhook_event(db, wd.user_id, "withdrawal.done", {
        "withdrawal_id": wd.id,
        "amount": wd.amount,
        "currency": "XOF",
        "status": wd.status,
        "reference": wd.reference,
        "stripe_payout_id": wd.stripe_payout_id
    })
    return {"status": wd.status}

@router.post("/withdrawals/{withdrawal_id}/cancel")
async def cancel_withdrawal(
    withdrawal_id: str,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
    workspace_id: str = Header(None, alias="X-Workspace-Id")
):
    owner_id = get_workspace_owner_id(current_user, workspace_id, db)
    wd = (db.query(Withdrawal).filter(Withdrawal.id == withdrawal_id, Withdrawal.user_id == owner_id).first())
    if not wd:
        raise HTTPException(status_code=404, detail="Retrait introuvable.")
    if wd.status != "pending":
        raise HTTPException(status_code=400, detail=f"Impossible d'annuler ce retrait car son statut est déjà '{wd.status}'.")
    if not wd.stripe_payout_id:
        wd.status = "canceled"
        wd.processed_at = datetime.now(timezone.utc)
        wallet = (db.query(Wallet).filter(Wallet.id == wd.wallet_id).first())
        if not wallet:
            raise HTTPException(status_code=500, detail="Wallet introuvable.")
        wallet.pending -= wd.amount
        wallet.available += wd.amount
        if wallet.pending < 0:
            wallet.pending = 0
        tx = (db.query(WalletTransaction).filter(WalletTransaction.reference == wd.reference).first())
        if tx:
            tx.status = "canceled"
            tx.description = "Retrait annulé"
        db.commit()
        return {"success": True, "message": "Retrait annulé et fonds recrédités."}
    try:
        payout = stripe.Payout.retrieve(
            wd.stripe_payout_id
        )
        if payout.status != "pending":
            raise HTTPException(
                status_code=400,
                detail=(
                    "Ce retrait ne peut plus être annulé. "
                    f"Statut Stripe : {payout.status}"
                )
            )
        stripe.Payout.cancel(
            wd.stripe_payout_id
        )
        wd.status = "canceled"
        wd.processed_at = datetime.now(timezone.utc)
        wallet = (
            db.query(Wallet)
            .filter(Wallet.id == wd.wallet_id)
            .first()
        )
        if not wallet:
            raise HTTPException(status_code=500, detail="Wallet introuvable.")
        wallet.pending -= wd.amount
        wallet.available += wd.amount
        if wallet.pending < 0:
            wallet.pending = 0
        tx = (db.query(WalletTransaction).filter(WalletTransaction.reference == wd.reference).first())
        if tx:
            tx.status = "canceled"
            tx.description = "Retrait annulé"
        db.commit()
        return {"success": True, "message": "Retrait annulé avec succès et fonds recrédités."}
    except stripe.error.StripeError as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=f"Erreur Stripe : {e.user_message or str(e)}")
    except HTTPException:
        db.rollback()
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Erreur interne : {str(e)}")